<?php
include_once ('../inc/headers.php');

$serverClient = new GetStream\StreamChat\Client("amd8myw2784v", "cfn8d4u53mmyrx4jcda5zeuk9un39rvvg4p9mpy9febqu3rjqkwstqdazb6s8vtj");

//$username = $_POST['username'];
//$fullNames = $_POST['fullNames'];
//$avatar = $_POST['imageUrl'];
//$team = $_POST['team'];
//$teamImageUrl = $_POST['teamImageUrl'];

$username = 'melokuhle';
$fullNames = 'Melokuhle Ndlovu';
$avatar = 'avatar.png';
$team = 'Mamelodi Sundowns';
$teamImageUrl ='2699.png';

try {
    $token = $serverClient->createToken($username);

    $streamUser = [
        'id' => $username,
        'role' => 'user',
        'fullName' => $fullNames,
        'photo'=> $avatar,
        'team' => $team,
        'teamImageUrl' => $teamImageUrl
    ];

    $createdUser =  $serverClient->upsertUser($streamUser);

    echo json_encode($token);

} catch (Exception $e) {

    echo $e;
}